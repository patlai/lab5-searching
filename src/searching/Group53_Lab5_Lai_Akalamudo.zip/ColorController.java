package searching;

public interface ColorController {
	public void processColorData(int[] color);


	public int[] readColorData();
}
